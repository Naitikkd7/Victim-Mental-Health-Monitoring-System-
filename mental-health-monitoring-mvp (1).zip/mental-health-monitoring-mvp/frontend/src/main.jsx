import React, { useEffect, useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import axios from 'axios';
import './styles.css';

const API = import.meta.env.VITE_API_URL || 'http://localhost:4000/api';
const api = axios.create({ baseURL: API });

function App() {
  const [session, setSession] = useState(() => JSON.parse(localStorage.getItem('session') || 'null'));
  const [page, setPage] = useState('home');

  useEffect(() => {
    if (session?.token) api.defaults.headers.common.Authorization = `Bearer ${session.token}`;
  }, [session]);

  if (!session) return <Login onLogin={s => { localStorage.setItem('session', JSON.stringify(s)); setSession(s); }} />;

  const logout = () => { localStorage.removeItem('session'); setSession(null); };

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">Wellbeing<span>Monitor</span></div>
        <div className="role-badge">{session.user.role.toUpperCase()}</div>
        <button onClick={() => setPage('home')}>Overview</button>
        {session.user.role === 'victim' && <button onClick={() => setPage('checkin')}>Wellbeing Check-in</button>}
        {(session.user.role === 'counsellor' || session.user.role === 'admin') && <button onClick={() => setPage('alerts')}>Alerts</button>}
        {(session.user.role === 'counsellor' || session.user.role === 'admin') && <button onClick={() => setPage('victims')}>Monitored Cases</button>}
        <button className="logout" onClick={logout}>Sign out</button>
      </aside>
      <main className="main-content">
        <header>
          <div><p className="eyebrow">Secure prototype workspace</p><h1>{page === 'checkin' ? 'Wellbeing check-in' : page === 'alerts' ? 'Risk alerts' : page === 'victims' ? 'Monitored cases' : 'Dashboard'}</h1></div>
          <div className="user-chip">{session.user.name}</div>
        </header>
        {page === 'checkin' ? <CheckIn /> : page === 'alerts' ? <Alerts /> : page === 'victims' ? <Victims /> : <Overview role={session.user.role} />}
      </main>
    </div>
  );
}

function Login({ onLogin }) {
  const [email, setEmail] = useState('victim@example.com');
  const [password, setPassword] = useState('victim123');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const submit = async e => {
    e.preventDefault(); setBusy(true); setError('');
    try { const { data } = await api.post('/auth/login', { email, password }); onLogin(data); }
    catch { setError('Login failed. Check the demo credentials.'); }
    finally { setBusy(false); }
  };
  return <div className="login-page"><div className="login-card">
    <p className="eyebrow">Problem Statement 26094 · Prototype</p>
    <h1>Victim Wellbeing Monitor</h1>
    <p className="subtle">A demo interface for periodic check-ins, longitudinal distress trends and human-reviewed alerts.</p>
    <form onSubmit={submit}>
      <label>Email<input value={email} onChange={e => setEmail(e.target.value)} /></label>
      <label>Password<input type="password" value={password} onChange={e => setPassword(e.target.value)} /></label>
      {error && <div className="error">{error}</div>}
      <button className="primary" disabled={busy}>{busy ? 'Signing in…' : 'Sign in'}</button>
    </form>
    <div className="demo-box"><b>Demo:</b> victim@example.com / victim123<br/>counsellor@example.com / counsellor123</div>
  </div></div>;
}

function Overview({ role }) {
  const [data, setData] = useState(null);
  const [history, setHistory] = useState([]);
  useEffect(() => {
    if (role === 'victim') api.get('/victims/check-ins').then(r => setHistory(r.data));
    else api.get('/dashboard/summary').then(r => setData(r.data));
  }, [role]);

  if (role === 'victim') {
    const latest = history.at(-1);
    return <section>
      <div className="hero-card"><div><p className="eyebrow">Private check-in space</p><h2>Your wellbeing timeline</h2><p className="subtle">Share how you are feeling so the system can track changes over time.</p></div><div className="score-ring">{latest?.ai?.distress_score ?? '—'}<small>score</small></div></div>
      <div className="grid-3"><Stat title="Check-ins" value={history.length}/><Stat title="Latest risk" value={latest?.ai?.risk_level || 'Not assessed'}/><Stat title="Trend" value={latest?.ai?.trend || 'No data'}/></div>
      <History items={history}/>
    </section>;
  }
  return <section>
    <div className="grid-4"><Stat title="Monitored victims" value={data?.monitoredVictims ?? '—'}/><Stat title="Active cases" value={data?.totalCases ?? '—'}/><Stat title="Open alerts" value={data?.openAlerts ?? '—'}/><Stat title="High-risk latest assessments" value={data?.highRiskCases ?? '—'}/></div>
    <div className="panel"><h2>Latest check-ins</h2><History items={data?.latestCheckIns || []}/></div>
  </section>;
}

function CheckIn() {
  const [text, setText] = useState('');
  const [mood, setMood] = useState(3);
  const [sleepHours, setSleepHours] = useState(7);
  const [engagement, setEngagement] = useState(0.8);
  const [result, setResult] = useState(null);
  const [busy, setBusy] = useState(false);
  const submit = async e => {
    e.preventDefault(); setBusy(true); setResult(null);
    try { const { data } = await api.post('/victims/check-in', { text, mood, sleepHours, engagement, language: 'en' }); setResult(data); setText(''); }
    catch (e) { setResult({ error: e.response?.data?.error || 'Unable to submit check-in' }); }
    finally { setBusy(false); }
  };
  return <section className="two-col"><div className="panel"><h2>How are you feeling?</h2><p className="subtle">Describe your current experience in your own words.</p>
    <form onSubmit={submit}>
      <label>Check-in message<textarea rows="7" value={text} onChange={e => setText(e.target.value)} placeholder="For example: I have been feeling anxious and having trouble sleeping…" required /></label>
      <div className="field-row"><label>Mood (1–5)<input type="number" min="1" max="5" value={mood} onChange={e => setMood(Number(e.target.value))}/></label><label>Sleep hours<input type="number" min="0" max="24" step="0.5" value={sleepHours} onChange={e => setSleepHours(Number(e.target.value))}/></label></div>
      <button className="primary" disabled={busy}>{busy ? 'Analysing…' : 'Submit check-in'}</button>
    </form>
  </div><div className="panel"><h2>Latest analysis</h2>{result ? <Analysis result={result}/> : <p className="subtle">Your result will appear here after submission.</p>}</div></section>;
}

function Analysis({ result }) {
  if (result.error) return <div className="error">{result.error}</div>;
  return <div>
    <div className="analysis-score"><span>{result.ai.distress_score}</span><small>/ 100 prototype score</small></div>
    <div className={`risk risk-${result.ai.risk_level.toLowerCase()}`}>{result.ai.risk_level} RISK</div>
    <p className="subtle">{result.ai.trend_note}</p>
    <h3>Detected factors</h3>
    {result.ai.factors?.length ? <ul>{result.ai.factors.map(x => <li key={x}>{x}</li>)}</ul> : <p className="subtle">No additional demo factors detected.</p>}
    <div className="notice">This prototype output is not a diagnosis and should not be used alone for high-stakes decisions.</div>
  </div>;
}

function History({ items }) {
  if (!items?.length) return <p className="subtle">No check-ins recorded yet.</p>;
  return <div className="timeline">{items.map(item => <div className="timeline-item" key={item.id}><div className="timeline-score">{item.ai?.distress_score ?? '—'}</div><div><b>{item.ai?.risk_level || '—'}</b><div className="subtle">{new Date(item.createdAt).toLocaleString()}</div><p>{item.text}</p></div></div>)}</div>;
}

function Alerts() {
  const [alerts, setAlerts] = useState([]);
  const refresh = () => api.get('/alerts').then(r => setAlerts(r.data));
  useEffect(refresh, []);
  const acknowledge = async id => { await api.post(`/alerts/${id}/acknowledge`); refresh(); };
  return <section className="panel"><h2>Risk alerts</h2><p className="subtle">Alerts are signals for human review, not automated conclusions.</p>{alerts.length ? alerts.map(a => <div className="alert-row" key={a.id}><div><div className={`risk risk-${a.severity.toLowerCase()}`}>{a.severity}</div><b>Distress score: {a.distressScore}</b><div className="subtle">{new Date(a.createdAt).toLocaleString()}</div><p>{a.reason}</p></div><button onClick={() => acknowledge(a.id)} disabled={a.status !== 'open'}>{a.status === 'open' ? 'Acknowledge' : 'Acknowledged'}</button></div>) : <p className="subtle">No alerts.</p>}</section>;
}

function Victims() {
  const [victims, setVictims] = useState([]);
  useEffect(() => { api.get('/dashboard/victims').then(r => setVictims(r.data)); }, []);
  return <section className="panel"><h2>Monitored cases</h2><div className="table"><div className="tr th"><span>Reference</span><span>Risk</span><span>Score</span><span>Trend</span><span>Last check-in</span></div>{victims.map(v => <div className="tr" key={v.caseId}><span>{v.reference}</span><span>{v.riskLevel}</span><span>{v.distressScore ?? '—'}</span><span>{v.trend}</span><span>{v.lastCheckIn ? new Date(v.lastCheckIn).toLocaleString() : '—'}</span></div>)}</div></section>;
}

function Stat({ title, value }) { return <div className="stat"><div className="subtle">{title}</div><strong>{value}</strong></div>; }

createRoot(document.getElementById('root')).render(<App />);
