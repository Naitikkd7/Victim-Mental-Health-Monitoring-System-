import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import axios from 'axios';
import { randomUUID } from 'crypto';

dotenv.config();

const app = express();
app.use(cors({ origin: process.env.CORS_ORIGIN || 'http://localhost:5173' }));
app.use(express.json({ limit: '1mb' }));

const PORT = Number(process.env.PORT || 4000);
const JWT_SECRET = process.env.JWT_SECRET || 'dev-secret';
const AI_SERVICE_URL = process.env.AI_SERVICE_URL || 'http://localhost:8001';

const users = [
  { id: 'u1', name: 'Demo Victim', email: 'victim@example.com', role: 'victim', district: 'Bengaluru Urban', passwordHash: bcrypt.hashSync('victim123', 10) },
  { id: 'u2', name: 'Demo Counsellor', email: 'counsellor@example.com', role: 'counsellor', district: 'Bengaluru Urban', passwordHash: bcrypt.hashSync('counsellor123', 10) },
  { id: 'u3', name: 'Demo Admin', email: 'admin@example.com', role: 'admin', district: 'Bengaluru Urban', passwordHash: bcrypt.hashSync('admin123', 10) }
];

const cases = [
  { id: 'case-001', victimId: 'u1', reference: 'NHAA-26094-001', status: 'active', district: 'Bengaluru Urban', createdAt: new Date().toISOString() }
];

const checkIns = [];
const alerts = [];
const interventions = [];

function signToken(user) {
  return jwt.sign({ sub: user.id, role: user.role }, JWT_SECRET, { expiresIn: '2h' });
}

function auth(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'Missing authentication token' });
  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    return res.status(401).json({ error: 'Invalid or expired token' });
  }
}

function allow(...roles) {
  return (req, res, next) => {
    if (!roles.includes(req.user.role)) return res.status(403).json({ error: 'Insufficient permissions' });
    next();
  };
}

function userById(id) {
  return users.find(u => u.id === id);
}

function caseForUser(userId) {
  return cases.find(c => c.victimId === userId);
}

app.get('/api/health', (req, res) => {
  res.json({ ok: true, service: 'node-backend' });
});

app.post('/api/auth/login', async (req, res) => {
  const { email, password } = req.body || {};
  const user = users.find(u => u.email.toLowerCase() === String(email || '').toLowerCase());
  if (!user || !(await bcrypt.compare(String(password || ''), user.passwordHash))) {
    return res.status(401).json({ error: 'Invalid email or password' });
  }
  const token = signToken(user);
  res.json({
    token,
    user: { id: user.id, name: user.name, email: user.email, role: user.role, district: user.district }
  });
});

app.get('/api/me', auth, (req, res) => {
  const user = userById(req.user.sub);
  if (!user) return res.status(404).json({ error: 'User not found' });
  res.json({ id: user.id, name: user.name, email: user.email, role: user.role, district: user.district });
});

app.get('/api/victim/case', auth, allow('victim'), (req, res) => {
  const item = caseForUser(req.user.sub);
  res.json(item || null);
});

app.post('/api/victims/check-in', auth, allow('victim'), async (req, res) => {
  const { text, language = 'en', mood = null, sleepHours = null, engagement = null } = req.body || {};
  if (!String(text || '').trim()) return res.status(400).json({ error: 'Check-in text is required' });

  let aiResult;
  try {
    const response = await axios.post(`${AI_SERVICE_URL}/analyze`, {
      text: String(text),
      language,
      mood,
      sleep_hours: sleepHours,
      engagement
    }, { timeout: 5000 });
    aiResult = response.data;
  } catch (error) {
    console.error('AI service unavailable:', error.message);
    return res.status(503).json({ error: 'AI analysis service is unavailable' });
  }

  const previous = [...checkIns]
    .filter(c => c.victimId === req.user.sub)
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))[0];

  if (previous?.ai?.distress_score != null) {
    const delta = aiResult.distress_score - previous.ai.distress_score;
    aiResult.trend = delta >= 5 ? 'increasing' : delta <= -5 ? 'decreasing' : 'stable';
    aiResult.trend_delta = delta;
  } else {
    aiResult.trend = 'baseline';
    aiResult.trend_delta = null;
  }

  const record = {
    id: randomUUID(),
    victimId: req.user.sub,
    caseId: caseForUser(req.user.sub)?.id || null,
    createdAt: new Date().toISOString(),
    text: String(text),
    language,
    mood,
    sleepHours,
    engagement,
    ai: aiResult
  };
  checkIns.push(record);

  if (aiResult.risk_level === 'HIGH' || aiResult.distress_score >= 70) {
    alerts.unshift({
      id: randomUUID(),
      victimId: req.user.sub,
      caseId: record.caseId,
      type: 'DISTRESS_THRESHOLD',
      severity: aiResult.risk_level,
      distressScore: aiResult.distress_score,
      reason: 'Prototype threshold exceeded',
      status: 'open',
      createdAt: new Date().toISOString()
    });
  }

  res.status(201).json(record);
});

app.get('/api/victims/check-ins', auth, allow('victim'), (req, res) => {
  res.json(checkIns.filter(c => c.victimId === req.user.sub));
});

app.get('/api/dashboard/summary', auth, allow('counsellor', 'admin'), (req, res) => {
  const relevantCases = cases.filter(c => c.district === userById(req.user.sub)?.district);
  const relevantVictims = new Set(relevantCases.map(c => c.victimId));
  const relevantAlerts = alerts.filter(a => relevantVictims.has(a.victimId));
  const latest = [...checkIns]
    .filter(c => relevantVictims.has(c.victimId))
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  const latestByVictim = new Map();
  for (const item of latest) if (!latestByVictim.has(item.victimId)) latestByVictim.set(item.victimId, item);

  res.json({
    district: userById(req.user.sub)?.district || null,
    totalCases: relevantCases.length,
    openAlerts: relevantAlerts.filter(a => a.status === 'open').length,
    highRiskCases: [...latestByVictim.values()].filter(x => x.ai.risk_level === 'HIGH').length,
    monitoredVictims: relevantVictims.size,
    latestCheckIns: latest.slice(0, 10)
  });
});

app.get('/api/dashboard/victims', auth, allow('counsellor', 'admin'), (req, res) => {
  const district = userById(req.user.sub)?.district;
  const result = cases
    .filter(c => c.district === district)
    .map(c => {
      const victim = userById(c.victimId);
      const history = checkIns.filter(x => x.victimId === c.victimId).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
      const latest = history[0] || null;
      return {
        caseId: c.id,
        reference: c.reference,
        name: victim?.name,
        district: c.district,
        riskLevel: latest?.ai?.risk_level || 'NOT_ASSESSED',
        distressScore: latest?.ai?.distress_score ?? null,
        trend: latest?.ai?.trend || 'NO_DATA',
        lastCheckIn: latest?.createdAt || null
      };
    });
  res.json(result);
});

app.get('/api/alerts', auth, allow('counsellor', 'admin'), (req, res) => {
  const district = userById(req.user.sub)?.district;
  const victimIds = new Set(cases.filter(c => c.district === district).map(c => c.victimId));
  res.json(alerts.filter(a => victimIds.has(a.victimId)));
});

app.post('/api/alerts/:id/acknowledge', auth, allow('counsellor', 'admin'), (req, res) => {
  const alert = alerts.find(a => a.id === req.params.id);
  if (!alert) return res.status(404).json({ error: 'Alert not found' });
  alert.status = 'acknowledged';
  alert.acknowledgedBy = req.user.sub;
  alert.acknowledgedAt = new Date().toISOString();
  res.json(alert);
});

app.post('/api/interventions', auth, allow('counsellor', 'admin'), (req, res) => {
  const { victimId, type, notes = '' } = req.body || {};
  if (!victimId || !type) return res.status(400).json({ error: 'victimId and type are required' });
  const intervention = {
    id: randomUUID(), victimId, type, notes,
    assignedBy: req.user.sub,
    status: 'planned',
    createdAt: new Date().toISOString()
  };
  interventions.unshift(intervention);
  res.status(201).json(intervention);
});

// Integration-ready placeholders for approved SMS/IVR/channel providers.
app.post('/api/integrations/follow-up', auth, allow('counsellor', 'admin'), (req, res) => {
  const { channel, victimId, message } = req.body || {};
  if (!channel || !victimId || !message) return res.status(400).json({ error: 'channel, victimId and message are required' });
  res.status(202).json({
    accepted: true,
    provider: 'demo',
    channel,
    victimId,
    message,
    note: 'Connect a verified SMS/IVR/chat provider here in production.'
  });
});

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: 'Unexpected server error' });
});

app.listen(PORT, () => console.log(`Node API running on http://localhost:${PORT}`));
