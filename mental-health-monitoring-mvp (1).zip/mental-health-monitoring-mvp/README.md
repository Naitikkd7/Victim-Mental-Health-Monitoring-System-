# AI-Powered Dynamic Mental Health Monitoring & Distress Prediction System

Prototype implementation for Problem Statement 26094.

## Stack
- Frontend: React + Vite
- Main backend: Node.js + Express
- AI service: Python + FastAPI + scikit-learn
- Data: PostgreSQL (production path) with a Node in-memory fallback for quick demo

## Important
This repository is a **hackathon/demo prototype**. The distress score is a software demonstration and is **not a medical diagnosis, clinical risk instrument, or substitute for a trained professional**. Do not use the included model to make real-world decisions about people's safety, treatment, legal status, witness protection, or benefits.

## Features implemented
- Role-aware login demo (victim / counsellor / admin)
- Victim wellbeing check-in
- Text analysis through Python AI service
- Dynamic distress score and trend history
- Threshold-based alert creation
- Counsellor/admin dashboard
- Intervention tracking
- Multilingual field support (language selector; analysis is demo English-focused)
- API boundaries for future SMS/IVR/mobile integrations

## Project structure

```text
mental-health-monitoring-mvp/
├── frontend/
├── backend/
├── ai-service/
└── db/
```

## Run

### 1. AI service
```bash
cd ai-service
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app:app --reload --port 8001
```

### 2. Node backend
```bash
cd backend
npm install
cp .env.example .env
npm run dev
```

### 3. React frontend
```bash
cd frontend
npm install
npm run dev
```

Open the Vite URL shown in the terminal, normally `http://localhost:5173`.

Demo accounts are seeded by the Node backend:
- Victim: `victim@example.com` / `victim123`
- Counsellor: `counsellor@example.com` / `counsellor123`
- Admin: `admin@example.com` / `admin123`

## Production hardening still required
- PostgreSQL persistence and encrypted backups
- Strong secrets from a secret manager
- HttpOnly secure cookies or equivalent hardened token strategy
- Key management / encryption at rest and in transit
- Audit logging with tamper resistance
- Consent and data-retention workflows
- Human review before any high-stakes action
- Properly validated and approved clinical/risk models
- Bias, calibration, red-team, accessibility, and multilingual validation
- Real verified SMS/IVR integrations
