from datetime import datetime, timezone
from typing import Optional

from fastapi import FastAPI
from pydantic import BaseModel, Field
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline

app = FastAPI(title="Distress Analysis Prototype", version="1.0.0")

# Tiny synthetic dataset ONLY to make the demo self-contained.
# It is not clinically validated and must not be treated as a real mental-health model.
TRAIN_TEXTS = [
    "I feel calm today and I slept well",
    "I am doing okay and feel supported",
    "I feel normal and can focus on work",
    "I am anxious and worried most of the day",
    "I am scared and cannot stop thinking about what happened",
    "I feel overwhelmed and exhausted",
    "I cannot sleep and I keep having frightening thoughts",
    "I feel hopeless and completely trapped",
    "I am in danger and extremely afraid",
]
TRAIN_LABELS = [
    "LOW", "LOW", "LOW", "MODERATE", "MODERATE", "MODERATE",
    "HIGH", "HIGH", "HIGH"
]

MODEL = Pipeline([
    ("tfidf", TfidfVectorizer(ngram_range=(1, 2), lowercase=True)),
    ("clf", LogisticRegression(max_iter=1000))
])
MODEL.fit(TRAIN_TEXTS, TRAIN_LABELS)

HIGH_WORDS = {"hopeless", "trapped", "danger", "unsafe", "suicidal", "kill", "die", "threat"}
MODERATE_WORDS = {"anxious", "worried", "scared", "overwhelmed", "exhausted", "fear", "afraid", "stress"}

class AnalyzeRequest(BaseModel):
    text: str = Field(min_length=1, max_length=5000)
    language: str = "en"
    mood: Optional[int] = Field(default=None, ge=1, le=5)
    sleep_hours: Optional[float] = Field(default=None, ge=0, le=24)
    engagement: Optional[float] = Field(default=None, ge=0, le=1)


def score_request(req: AnalyzeRequest):
    text = req.text.lower().strip()
    predicted = MODEL.predict([text])[0]
    probabilities = MODEL.predict_proba([text])[0]
    classes = MODEL.classes_.tolist()
    confidence = float(max(probabilities))

    score = {"LOW": 25, "MODERATE": 52, "HIGH": 80}[predicted]
    factors = []

    words = set(text.replace(".", " ").replace(",", " ").split())
    high_hits = sorted(words.intersection(HIGH_WORDS))
    moderate_hits = sorted(words.intersection(MODERATE_WORDS))

    if high_hits:
        score += min(15, 5 * len(high_hits))
        factors.append("high-severity language detected")
    if moderate_hits:
        score += min(10, 3 * len(moderate_hits))
        factors.append("anxiety/stress language detected")
    if req.mood is not None and req.mood <= 2:
        score += 8
        factors.append("low self-reported mood")
    if req.sleep_hours is not None and req.sleep_hours < 5:
        score += 8
        factors.append("low reported sleep")
    if req.engagement is not None and req.engagement < 0.3:
        score += 5
        factors.append("low engagement")

    score = int(max(0, min(100, score)))
    risk = "LOW" if score < 40 else "MODERATE" if score < 70 else "HIGH"

    return {
        "distress_score": score,
        "risk_level": risk,
        "model_prediction": predicted,
        "model_confidence": round(confidence, 3),
        "factors": factors,
        "trend_note": "Compare with prior check-ins; one interaction should not be interpreted in isolation.",
        "generated_at": datetime.now(timezone.utc).isoformat()
    }

@app.get("/health")
def health():
    return {"ok": True, "service": "ai-service"}

@app.post("/analyze")
def analyze(req: AnalyzeRequest):
    # For this demo, non-English input receives the same lexical model but is flagged.
    result = score_request(req)
    if req.language.lower() != "en":
        result["translation_status"] = "demo-only: multilingual model not connected"
    return result
