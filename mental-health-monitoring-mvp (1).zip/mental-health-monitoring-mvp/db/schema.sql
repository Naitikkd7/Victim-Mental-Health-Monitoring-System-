CREATE TABLE users (
  id UUID PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('victim', 'counsellor', 'admin')),
  district TEXT,
  password_hash TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE cases (
  id UUID PRIMARY KEY,
  victim_id UUID NOT NULL REFERENCES users(id),
  case_reference TEXT UNIQUE NOT NULL,
  status TEXT NOT NULL,
  district TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE check_ins (
  id UUID PRIMARY KEY,
  victim_id UUID NOT NULL REFERENCES users(id),
  case_id UUID REFERENCES cases(id),
  text_encrypted BYTEA,
  language TEXT NOT NULL,
  mood SMALLINT,
  sleep_hours NUMERIC,
  engagement NUMERIC,
  distress_score SMALLINT,
  risk_level TEXT,
  ai_explanation JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE alerts (
  id UUID PRIMARY KEY,
  victim_id UUID NOT NULL REFERENCES users(id),
  case_id UUID REFERENCES cases(id),
  type TEXT NOT NULL,
  severity TEXT NOT NULL,
  distress_score SMALLINT,
  reason TEXT,
  status TEXT NOT NULL DEFAULT 'open',
  acknowledged_by UUID REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  acknowledged_at TIMESTAMPTZ
);

CREATE TABLE interventions (
  id UUID PRIMARY KEY,
  victim_id UUID NOT NULL REFERENCES users(id),
  type TEXT NOT NULL,
  notes TEXT,
  assigned_by UUID REFERENCES users(id),
  status TEXT NOT NULL DEFAULT 'planned',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
